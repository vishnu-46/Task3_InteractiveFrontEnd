import React from 'react';

const TodoList = ({ setPage }) => {
  return (
    <div className="container">
      <h1>Todo List</h1>
      
    </div>
  );
};

export default TodoList;
